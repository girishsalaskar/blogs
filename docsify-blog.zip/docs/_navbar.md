<a href="/">Home</a>
<span style="margin-left:16px"></span>
<a href="/about">About</a>
