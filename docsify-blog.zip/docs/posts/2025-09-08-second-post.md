# Second Post

*September 08, 2025*

A sample second post. Rename, add, or remove files under `docs/posts/` to manage posts.
