<div class="cover">
# Welcome to My Docsify Blog
A lightweight blog powered by **Docsify** — write posts in Markdown and deploy via GitHub Pages.
</div>

## Latest posts
<ul class="post-list">
- [2025-09-09 — Welcome to your Docsify Blog](posts/2025-09-09-welcome.md)
- [2025-09-08 — Second Post](posts/2025-09-08-second-post.md)
</ul>
